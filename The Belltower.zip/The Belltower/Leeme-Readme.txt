Leeme.

Este programa lee un fichero .CSV en el que cada linea corresponde a un nombre de proteina, una coma(,), y la secuencia de esta proteina.

Produce un archivo MIDI(.mid) por cada proteina leida, con el nombre de la proteina, 
y un fichero "Huellas.mid" con el sonido asignado de cada tipo de aminoácido, (Positivos, Negativos, Neutros, Aromáticos y No Polares.

Este programa pertenece al conjunto de Protein Rhythm Music, que pone de manifiesto el ritmo intrínseco de cada proteina, segun el tipo de AA.

Copyright Florentino Sánchez-García, 2020.

Readme.

This program reads a .CSV file in which each line corresponds to a protein name, a comma (,), and the sequence of this protein.

Produces a MIDI file (.mid) for each protein readed, with the name of the protein,
and a "Huellas.mid" file with the assigned sound of each type of amino acid, (Positive, Negative, Neutral, Aromatic and Non-Polar.

This program belongs to the set of Protein Rhythm Music, which reveals the intrinsic rhythm of each protein, according to the type of AA.

Copyright Florentino Sánchez-García, 2020.

