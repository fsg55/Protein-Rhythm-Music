Leeme - Readme.

LEEME:

Este programa convierte cada secuencia de Aminoácidos, (proteina), en una secuencia de trinos, (de ahí el nombre de Pajarería de Proteinas- The Protein's Birdhouse).

Para cada longitud de secuencia se seleccionan un conjunto distinto de pájaros o trinos. 

Para cada  secuencia suenan simultaneamente 4 tipos de trinos y un quinto tipo que es el silencio, que hace más melodiosa su audición. 

Escuchar el archivo Huellas05.mid en el que se puede apreciar la codificación auditiva de cada tipo de trino con su correspondencia al tipo de aminoácido que compone la secuencia, que viene indicada en el título del archivo.

Los grupos de aminoácidos codificados son:
 Polares Positivos, Negativos y Neutros,
 Aromáticos y
 No Polares o Alifáticos. 

Como se pueden apreciar esta es una versión de los programas ProteinRhythmMusic, que ponen de manifiesto el ritmo intrínseco de cada proteina, en formas de percusión en función de la consitución de su secuencia de AminoAcidos.

Los Midis (archivos de audio) producidos por este programa tambien pueden ser oidos y vistos con MidiTrail.

El el archivo ejemplo.csv, tienen una muestra de la entrada de datos al programa que consiste en una sola linea por cada proteina con el formato: nombre,secuencia.

En este zip también hay otro fichero .csv que contiene todos los genes humanos relacionados con enfermedad descritos en el compendio KEGG-human-diseases(KEGG: Kyoto Encyclopedia of Genes and Genomes).

Que lo disfruten. :)

Copyright: Florentino Sánchez-García, 2020.


README:

This program converts each sequence of Amino Acids, (protein), into a sequence of trills, (hence the name of Protein's Birdhouse).

For each sequence length a different set of birds or trills is selected.

For each sequence, 4 types of trills sound simultaneously and a fifth type is silence, which makes your listening more melodious.

Listen to the file Huellas05.mid in which you can see the auditory coding of each type of trill with its correspondence to the type of amino acid that makes up the sequence, which is indicated in the file title.

The encoded amino acid groups are:
 Polar: Positive, Negative and Neutral,
 Aromatic and
 Non-polar or aliphatic.

As you can see, this is a version of the ProteinRhythmMusic programs, which reveal the intrinsic rhythm of each protein, in percussion forms depending on the constitution of its amino acid sequence.

Midis (audio files) produced by this program can also be heard and viewed with MidiTrail.

In the ejemplo.csv file, they have a sample of the data input to the program that consists of a single line for each protein with the format: name, sequence.

In this zip there is also another .csv file that contains all the disease related human genes described in the KEGG-human-diseases compendium (KEGG: Kyoto Encyclopedia of Genes and Genomes).

Enjoy it. :)

Copyright: Florentino Sánchez-García, 2020.



 